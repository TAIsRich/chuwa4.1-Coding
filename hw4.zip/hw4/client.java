
public class client {
    public static void main(String[] args) {

        iyoutube sms = new sms();
        iyoutube email = new email();
        cviewer user1 = new cviewer("Jay", "sms", "9176281702");
        cviewer user2 = new cviewer("May", "email", "j@mail.com");
        sms.attach(user1);
        email.attach(user2);

        sms.Notify("new video is upload");
        email.Notify("new video is upload");
    }
}
