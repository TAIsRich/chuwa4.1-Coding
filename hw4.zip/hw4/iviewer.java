public interface iviewer {
    void update(String message);

    public String getname();

    public String getPreference();

    public String getEmail();

    public String getphone();

}
