public interface iyoutube {
    void attach(iviewer iview);

    void detach(iviewer iview);

    void Notify(String Message);

}
