
import java.util.List;

public class email implements iyoutube {
    private checktype a;
    private static List<iviewer> emailList;

    email() {
        check();
    }

    public void check() {
        a = checktype.getinstance();
        emailList = a.check(emailList);
    }

    @Override
    public void attach(iviewer iview) {

        try {
            if (!("email".equals(iview.getPreference())))
                throw new preferenceException("ops you type the preference you type doesnt match your email!");
            else if (iview.getEmail().contains("@")) {
                emailList.add(iview);
                System.out.println("hi! " + iview.getname() + " thank you for subscribing, we ll notify you in "
                        + iview.getPreference() + " in the future");
            } else
                throw new preferenceException("ops you must type in an email");
        } catch (preferenceException e) {
            System.out.print(e);
        }

    }

    @Override
    public void detach(iviewer iview) {
        emailList.remove(iview);
    }

    @Override
    public void Notify(String message) {

        for (iviewer i : emailList) {

            if (i.getPreference() == "email") {
                i.update(message);

            }
        }

        //

    }
}
