public class preferenceException extends Exception {

    public preferenceException(String s) {
        super(s);
    }
}
